"use client";

interface Props {

    images: string[];

}

export default function ResidentialGallery({

    images,

}: Props) {

    return (

        <div
            className="
                mt-6
                grid
                grid-cols-5
                gap-3
            "
        >

            {

                images.map(

                    image=>(

                        <img

                            key={image}

                            src={image}

                            alt=""

                            className="
                                aspect-square
                                rounded-xl
                                object-cover
                            "

                        />

                    )

                )

            }

        </div>

    );

}