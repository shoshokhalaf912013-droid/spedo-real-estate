"use client";

interface Props {

    video: string;

}

export default function ResidentialVideo({

    video,

}: Props) {

    return (

        <div
            className="
                overflow-hidden
                rounded-3xl
                border
                border-white/10
                bg-black
            "
        >

            <video

                className="
                    aspect-video
                    w-full
                "

                controls

                muted

                loop

                playsInline

            >

                <source

                    src={video}

                    type="video/mp4"

                />

            </video>

        </div>

    );

}