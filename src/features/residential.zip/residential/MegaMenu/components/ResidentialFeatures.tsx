"use client";

interface Props {

    features: string[];

}

export default function ResidentialFeatures({

    features,

}: Props) {

    return (

        <section
            className="
                mt-8
                rounded-3xl
                border
                border-white/10
                bg-[#08101E]
                p-8
            "
        >

            <div
                className="
                    mb-8
                "
            >

                <h2
                    className="
                        text-3xl
                        font-black
                        text-white
                    "
                >

                    Property Features

                </h2>

                <p
                    className="
                        mt-2
                        text-slate-400
                    "
                >

                    Discover the key amenities
                    and lifestyle advantages
                    offered by this residential
                    property type.

                </p>

            </div>

            <div
                className="
                    grid
                    gap-4
                    md:grid-cols-2
                    xl:grid-cols-3
                "
            >

                {

                    features.map(

                        feature=>(

                            <div

                                key={feature}

                                className="
                                    flex
                                    items-center
                                    gap-4
                                    rounded-2xl
                                    border
                                    border-white/10
                                    bg-[#020817]
                                    p-5
                                    transition
                                    hover:border-[#F97316]
                                "
                            >

                                <div
                                    className="
                                        flex
                                        h-12
                                        w-12
                                        items-center
                                        justify-center
                                        rounded-xl
                                        bg-[#F97316]
                                        text-xl
                                    "
                                >

                                    ✓

                                </div>

                                <div>

                                    <h4
                                        className="
                                            font-bold
                                            text-white
                                        "
                                    >

                                        {feature}

                                    </h4>

                                </div>

                            </div>

                        )

                    )

                }

            </div>

        </section>

    );

}