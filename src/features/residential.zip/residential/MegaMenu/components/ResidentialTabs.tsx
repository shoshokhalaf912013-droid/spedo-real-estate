"use client";

import { useState } from "react";

import {
    useResidential,
} from "../../store/ResidentialContext";

import ResidentialOverview
from "./ResidentialOverview";

import ResidentialInformation
from "./ResidentialInformation";

import ResidentialFeatures
from "./ResidentialFeatures";

import ResidentialAdvantages
from "./ResidentialAdvantages";

import ResidentialGallery
from "./ResidentialGallery";

import ResidentialVideo
from "./ResidentialVideo";

import ResidentialFAQ
from "./ResidentialFAQ";

const TABS = [

    "Overview",

    "Specifications",

    "Features",

    "Advantages",

    "Gallery",

    "Video",

    "FAQ",

] as const;

type Tab = typeof TABS[number];

export default function ResidentialTabs() {

    const {

        currentType,

    } = useResidential();

    const [

        active,

        setActive,

    ] = useState<Tab>(

        "Overview"

    );

    return (

        <section>

            <div
                className="
                    mb-8
                    flex
                    flex-wrap
                    gap-3
                "
            >

                {

                    TABS.map(

                        tab => (

                            <button

                                key={tab}

                                onClick={()=>

                                    setActive(tab)

                                }

                                className={`

                                    rounded-full
                                    px-6
                                    py-3
                                    text-sm
                                    font-bold
                                    transition

                                    ${

                                        active===tab

                                        ?

                                        "bg-[#F97316] text-black"

                                        :

                                        "border border-white/10 bg-[#08101E] text-white hover:border-[#F97316]"

                                    }

                                `}

                            >

                                {tab}

                            </button>

                        )

                    )

                }

            </div>

            {

                active==="Overview"

                &&

                <ResidentialOverview

                    data={currentType}

                />

            }

            {

                active==="Specifications"

                &&

                <ResidentialInformation

                    data={currentType}

                />

            }

            {

                active==="Features"

                &&

                <ResidentialFeatures

                    features={

                        currentType.features

                    }

                />

            }

            {

                active==="Advantages"

                &&

                <ResidentialAdvantages

                    advantages={

                        currentType.advantages

                    }

                />

            }

            {

                active==="Gallery"

                &&

                <ResidentialGallery

                    images={

                        currentType.gallery

                    }

                />

            }

            {

                active==="Video"

                &&

                <ResidentialVideo

                    video={

                        currentType.video

                    }

                />

            }

            {

                active==="FAQ"

                &&

                <ResidentialFAQ

                    faq={

                        currentType.faq

                    }

                />

            }

        </section>

    );

}