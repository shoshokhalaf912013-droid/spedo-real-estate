"use client";

import type { ResidentialType }
from "../../data/types";

interface Props {

    data: ResidentialType;

}

export default function ResidentialInformation({

    data,

}: Props) {

    return (

        <section
            className="
                rounded-3xl
                border
                border-white/10
                bg-[#08101E]
                p-8
            "
        >

            <div
                className="
                    mb-8
                "
            >

                <h2
                    className="
                        text-3xl
                        font-black
                        text-white
                    "
                >

                    Property Specifications

                </h2>

                <p
                    className="
                        mt-2
                        text-slate-400
                    "
                >

                    Explore the available specifications
                    for this residential property type.

                </p>

            </div>

            <div
                className="
                    grid
                    gap-6
                    md:grid-cols-2
                "
            >

                <SelectField
                    title="Floor"
                    items={
                        data.specifications.floors
                    }
                />

                <SelectField
                    title="View"
                    items={
                        data.specifications.views
                    }
                />

                <SelectField
                    title="Finishing"
                    items={
                        data.specifications.finishing
                    }
                />

                <SelectField
                    title="Furnishing"
                    items={
                        data.specifications.furnishing
                    }
                />

                <SelectField
                    title="Parking"
                    items={
                        data.specifications.parking
                    }
                />

                <SelectField
                    title="Balcony"
                    items={
                        data.specifications.balcony
                    }
                />

                <SelectField
                    title="Garden"
                    items={
                        data.specifications.garden
                    }
                />

                <SelectField
                    title="Roof"
                    items={
                        data.specifications.roof
                    }
                />

                <SelectField
                    title="Smart Home"
                    items={
                        data.specifications.smartHome
                    }
                />

                <SelectField
                    title="Elevators"
                    items={
                        data.specifications.elevators
                    }
                />

            </div>

        </section>

    );

}

interface SelectFieldProps {

    title: string;

    items: string[];

}

function SelectField({

    title,

    items,

}: SelectFieldProps) {

    return (

        <div>

            <label
                className="
                    mb-2
                    block
                    text-sm
                    font-semibold
                    text-slate-300
                "
            >

                {title}

            </label>

            <select
                className="
                    h-12
                    w-full
                    rounded-xl
                    border
                    border-white/10
                    bg-[#020817]
                    px-4
                    text-white
                    outline-none
                    transition
                    focus:border-[#F97316]
                "
            >

                <option>

                    Select {title}

                </option>

                {

                    items.map(

                        item=>(

                            <option

                                key={item}

                                value={item}

                            >

                                {item}

                            </option>

                        )

                    )

                }

            </select>

        </div>

    );

}