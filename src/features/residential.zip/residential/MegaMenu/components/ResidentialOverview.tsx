"use client";

import type { ResidentialType }
from "../../data/types";

interface Props {

    data: ResidentialType;

}

export default function ResidentialOverview({

    data,

}: Props) {

    return (

        <div
            className="
                rounded-3xl
                border
                border-white/10
                bg-[#08101E]
                p-8
            "
        >

            <h2
                className="
                    text-4xl
                    font-black
                    text-white
                "
            >

                {data.title}

            </h2>

            <p
                className="
                    mt-2
                    text-lg
                    text-[#F97316]
                "
            >

                {data.subtitle}

            </p>

            <p
                className="
                    mt-6
                    leading-8
                    text-slate-300
                "
            >

                {data.description}

            </p>

            <div
                className="
                    mt-10
                    grid
                    gap-6
                    lg:grid-cols-2
                "
            >

                <div>

                    <h3
                        className="
                            mb-4
                            text-xl
                            font-bold
                            text-white
                        "
                    >

                        Advantages

                    </h3>

                    <ul
                        className="
                            space-y-3
                        "
                    >

                        {

                            data.advantages.map(

                                item=>(

                                    <li
                                        key={item}
                                        className="
                                            text-slate-300
                                        "
                                    >

                                        ✓ {item}

                                    </li>

                                )

                            )

                        }

                    </ul>

                </div>

                <div>

                    <h3
                        className="
                            mb-4
                            text-xl
                            font-bold
                            text-white
                        "
                    >

                        Best For

                    </h3>

                    <ul
                        className="
                            space-y-3
                        "
                    >

                        {

                            data.suitableFor.map(

                                item=>(

                                    <li
                                        key={item}
                                        className="
                                            text-slate-300
                                        "
                                    >

                                        ✓ {item}

                                    </li>

                                )

                            )

                        }

                    </ul>

                </div>

            </div>

        </div>

    );

}